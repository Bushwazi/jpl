Yo!
START: 9:30pm
EBD: 1:05pm
1. Obviously I didn't do a thorough QA, so this is due to be buggy, but I feel like I took it pretty far considering.
2. I included the build folder, I call it '_src'.
  If you want to fire it off: 
    1. you need gulp installed globally `$ npm install -g gulp`, you may also need to 'gulp-cli'
    2. then cd into the folder `cd example/demo_demo/_src`
    3. install all dependencies `$ npm install`
    4. then just watch for changes `$ gulp watch`
    5. it watches the Stylus, Jade and js files in the _src directory
    6. There are also min verions of the css and js included
3. And I assume if you dig how I did this, we have a follow up conversation about my thought process...
4. I had to base break-points on when things broke (as opposed to matching the psd width), because some elements broke at special spots
5. If I had more time:
  I may animate some buttons on hover or something.
  I'd set up some image compression via gulp
  I'd test on some real devices