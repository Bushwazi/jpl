var gulp = require('gulp'),
    gutil = require('gulp-util'),
    stylus = require('gulp-stylus'),
    concat = require('gulp-concat'),
    uglify = require('gulp-uglify'),
    autoprefixer = require('gulp-autoprefixer'),
    minifycss = require('gulp-minify-css'),
    rename = require('gulp-rename'),
    imagemin = require('gulp-imagemin'),
    pngcrush = require('imagemin-pngcrush'),
    cmq = require('gulp-combine-media-queries'),
    removeLogs = require('gulp-removelogs'),
    jade = require('gulp-jade');
 
gulp.task('html', function() {
    gulp.src('./jade/*.jade')
        .pipe(jade({
            pretty: true,
        }).on('error', gutil.log))
        .pipe(gulp.dest('../'))
});

gulp.task('css', function () {
  gulp.src('./stylus/main.styl')
    .pipe(stylus().on('error', gutil.log))
    .pipe(cmq({ log: true }))
    .pipe(autoprefixer('last 3 version', 'Explorer 8').on('error', gutil.log))
    .pipe(gulp.dest('../assets/styles/'))
    .pipe(rename({suffix: '.min'} ).on('error', gutil.log))
    .pipe(minifycss({
        noAdvanced: true,
    }).on('error', gutil.log))
    .pipe(gulp.dest('../assets/styles/'));
});

gulp.task('js', function() {
    // create the main app js
    gulp.src([
        './js/init.js'
    ])
    .pipe(concat('main.js'))
    .pipe(gulp.dest('../assets/js/'))
    .pipe(rename({suffix: '.min'} ))
    .pipe(removeLogs().on('error', gutil.log))
    .pipe(uglify().on('error', gutil.log))
    .pipe(gulp.dest('../assets/js/'));
    // create a file out of the libs that need to load in the head
    gulp.src([
        // './js/lib/googleAnalytics.js',
        './js/lib/modernizr.js',
    ])
    .pipe(concat('head.js'))
    .pipe(gulp.dest('../assets/js/'))
    .pipe(rename({suffix: '.min'} ))
    .pipe(removeLogs().on('error', gutil.log))
    .pipe(uglify().on('error', gutil.log))
    .pipe(gulp.dest('../assets/js/'));
});

gulp.task('compress_images', function () {
    /*
        I just duplicated the "img" folder and called it "img_uncompressed". Then run this to recreate the "img" folder.
    */
    return gulp.src('../assets/img_uncompressed/**/*')
        .pipe(imagemin({
            progressive: true,
            svgoPlugins: [{removeViewBox: false}],
            use: [pngcrush()]
        }).on('error', gutil.log))
        .pipe(gulp.dest('../assets/img/'));
});

gulp.task('watch', function() {
    gulp.watch('../**/stylus/**/*.styl', ['css'])
        .on('change', function(evt) {
        console.log(evt.type, " ==> ", evt.path);
    });
    gulp.watch('../**/js/**/*.js', ['js'])
        .on('change', function(evt) {
        console.log(evt.type, " ==> ", evt.path);
    });
    gulp.watch('../**/jade/**/*.jade', ['html'])
        .on('change', function(evt) {
        console.log(evt.type, " ==> ", evt.path);
    });
});

gulp.task('default', ['css', 'js', 'html']);