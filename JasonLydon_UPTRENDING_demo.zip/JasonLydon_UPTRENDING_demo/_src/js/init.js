(function(){
  var upTrending = {
    init: function(){
      this.el();
    },
    el:function(){
    	$('.scroll-down').on('click', upTrending.jumpDown);
    },
    jumpDown: function(evt){
    	var labsListPos = $('.labs-list').offset().top - $('.main-header').outerHeight() - 20;
    	 $('html,body').animate({
          scrollTop: labsListPos + 'px'
        }, 1000);
    	evt.preventDefault();
    }
  }
  upTrending.init();
})();